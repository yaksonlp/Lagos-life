# Lagos Life — Mobile-ready multiplayer preview (0.3.0)

This is an **installable web app (PWA)** for Android and iPhone, plus desktop browsers. It is not yet a native App Store / Google Play package.

## What is included
- Three.js 3D Lagos-inspired neighborhood
- Multiplayer presence and position synchronization through Socket.IO
- Player name tags, join/leave notifications, and shared text chat
- On-screen movement controls for touch devices; keyboard controls for computers
- PWA manifest, app icons, service worker shell caching, and iPhone home-screen icon
- `/health` endpoint and a Render deployment blueprint

## Run it
Requires Node.js 18 or newer.

```bash
npm install
npm start
```

Then open `http://localhost:3000`. For phone installation and multiplayer across different devices, deploy it to an HTTPS host that supports persistent WebSocket connections. Opening `localhost` on your phone is not the same as opening the hosted game.

## Publish a live test link (Render)
1. Create a GitHub repository and upload the contents of this folder (the files inside this folder, not the ZIP itself).
2. Sign in to Render and create a **New Blueprint** from that repository, or create a Web Service manually.
3. Use build command `npm install`, start command `npm start`, and health check path `/health`. The included `render.yaml` sets these values.
4. Wait for deployment and open the HTTPS URL Render gives you.
5. Test multiplayer by opening the same URL on two devices or in two browser sessions with different names. Both must be online at the same time.

Hosting provider plans and free-tier limits can change. Confirm current plan and WebSocket support with the host before launch.

## Install on Android
1. Open the deployed HTTPS link in Chrome.
2. Open the browser menu (⋮).
3. Tap **Install app** or **Add to Home screen** (wording varies).
4. Launch Lagos Life from the home screen.

## Install on iPhone / iPad
1. Open the deployed HTTPS link in Safari.
2. Tap **Share**.
3. Choose **Add to Home Screen**.
4. Enable **Open as Web App** if shown, then tap **Add**.

The same live URL works on iPhone and Android; no separate game build is needed for this PWA route. Native store distribution is a separate later step and requires app-store accounts, store assets, review, and usually a native wrapper such as Capacitor.

## Controls
- Desktop: W/A/S/D to move, Shift to sprint, click the scene for mouse look, Esc to release.
- Phone/tablet: use the on-screen arrows and sprint button. Landscape orientation is recommended.

## Important: before a public launch
This is a prototype, not a finished commercial MMO. It currently has no accounts, saved progress, database, payment system, advanced missions, moderation dashboard, or production anti-cheat. Chat is shared with players in the same running server. Do not ask players to share personal or financial information. Add server-authoritative movement, rate limits, moderation/reporting, privacy terms, backups, and monitoring before advertising a public release.

## Troubleshooting
- `npm install` or `npm start` fails: confirm Node.js 18+ and check the terminal output.
- Game page loads but 3D scene does not: confirm the browser has internet access because Three.js is loaded from a CDN.
- Multiplayer shows disconnected: check the server logs and `/health`; ensure the host supports Socket.IO/WebSockets and that the page is opened via the host HTTPS URL.
- iPhone does not offer Add to Home Screen: open the URL in Safari, not an in-app browser, and make sure it uses HTTPS.
