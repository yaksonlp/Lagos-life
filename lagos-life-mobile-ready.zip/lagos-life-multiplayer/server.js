const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" },
  pingInterval: 25000,
  pingTimeout: 20000
});

const PORT = process.env.PORT || 3000;
const WORLD_LIMIT = 88;
const players = new Map();

app.use(express.static("public"));
app.get("/health", (_req, res) => {
  res.json({ ok: true, game: "Lagos Life", online: players.size });
});

function cleanName(value) {
  if (typeof value !== "string") return "Lagos Player";
  const name = value.trim().replace(/[<>]/g, "").slice(0, 18);
  return name || "Lagos Player";
}
function safePosition(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(-WORLD_LIMIT, Math.min(WORLD_LIMIT, n)) : fallback;
}
function publicPlayer(p) {
  return { id: p.id, name: p.name, x: p.x, z: p.z, yaw: p.yaw, color: p.color };
}

io.on("connection", socket => {
  socket.on("joinGame", payload => {
    const palette = [0x19a974, 0xe0a526, 0x4187c9, 0xc15c76, 0x8c6bd1, 0xd66d32];
    const color = palette[Math.floor(Math.random() * palette.length)];
    const p = {
      id: socket.id,
      name: cleanName(payload && payload.name),
      x: (Math.random() - 0.5) * 10,
      z: 28 + Math.random() * 8,
      yaw: 0,
      color,
      lastUpdate: 0
    };
    players.set(socket.id, p);
    socket.emit("worldState", [...players.values()].map(publicPlayer));
    socket.broadcast.emit("playerJoined", publicPlayer(p));
  });

  socket.on("move", data => {
    const p = players.get(socket.id);
    if (!p || !data || typeof data !== "object") return;
    const now = Date.now();
    // Basic rate limiting: at most 30 movement packets per second per client.
    if (now - p.lastUpdate < 28) return;
    p.lastUpdate = now;
    p.x = safePosition(data.x, p.x);
    p.z = safePosition(data.z, p.z);
    p.yaw = safePosition(data.yaw, p.yaw);
    socket.broadcast.emit("playerMoved", publicPlayer(p));
  });

  socket.on("chatMessage", raw => {
    if (typeof raw !== "string") return;
    const text = raw.trim().replace(/[<>]/g, "").slice(0, 160);
    if (!text) return;
    const p = players.get(socket.id);
    if (!p) return;
    io.emit("chatMessage", {
      id: socket.id,
      name: p.name,
      text,
      time: new Date().toISOString()
    });
  });

  socket.on("disconnect", () => {
    if (players.delete(socket.id)) io.emit("playerLeft", socket.id);
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Lagos Life server running at http://localhost:${PORT}`);
});
